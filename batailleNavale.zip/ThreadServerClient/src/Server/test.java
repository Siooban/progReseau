package Server;//cette classe sert � la r�solution de bug

public class test {
	


public String Renvoie() {
	return "test";
}}